/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package baseespacialinternacional;

/**
 *
 * @author Micael
 */
public abstract class UnidadOperativa {
    private String nombre;
    private String modulo;
    private TipoAtmosfera atmosferas;
}
   
    